export interface Snippet {
  id: string;
  storeName: string;
  themeName: string;
  date: string;
  author: string;
  code: string;
  tags?: string[];
}

export type SortOption = 'date-desc' | 'date-asc' | 'theme-asc';
