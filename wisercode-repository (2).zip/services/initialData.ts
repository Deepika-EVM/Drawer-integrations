import { Snippet } from '../types';

export const INITIAL_DATA: Snippet[] = [
  {
    id: '1',
    storeName: 'jerseys-megastore.myshopify.com',
    themeName: 'Local',
    date: '2025-12-09',
    author: 'D',
    code: `function wiseraddedtocart() {\n    window.refreshCart()\n}`
  },
  {
    id: '2',
    storeName: 'wooden-ships.myshopify.com',
    themeName: 'Symmetry',
    date: '2025-11-27',
    author: 'D',
    code: `function wiseraddedtocart() {\n  document.dispatchEvent(\n    new CustomEvent('dispatch:cart-drawer:refresh', {\n      bubbles: true,\n    })\n  );\n  document.dispatchEvent(new CustomEvent('dispatch:cart-drawer:open'));\n}\nwiseraddedtocart();`
  },
  {
    id: '3',
    storeName: 'shopnalli.myshopify.com',
    themeName: 'Horizon',
    date: '2025-11-11',
    author: 'D',
    code: `function wiseraddtocart() {\n  document.dispatchEvent(\n    new CustomEvent('cart:update', {\n      detail: {\n        data: {\n          source: 'manual-console',\n          sections: {},\n        },\n      },\n      bubbles: true,\n      composed: true,\n    })\n  );\n  const wscart = document.querySelector('.cart-drawer__dialog');\n  wscart.show();\n}\nwiseraddtocart();`
  },
  {
    id: '4',
    storeName: 'prostandard.myshopify.com',
    themeName: 'Craft',
    date: '2025-10-30',
    author: 'D',
    code: `async function wiseraddtocart() {\n    const wsres = await fetch('/?section_id=cart-icon-bubble');\n    const wsText = await wsres.text();\n    const wshtml = document.createElement('div');\n    wshtml.innerHTML = wsText;\n    const wsnewBox = wshtml.querySelector('#shopify-section-cart-icon-bubble')?.innerHTML;\n    const cartIconElement = document.querySelector('#cart-icon-bubble.header__icon--cart');\n    cartIconElement.innerHTML = wsnewBox;\n}\nwiseraddtocart()`
  },
  {
    id: '5',
    storeName: 'prostandard.myshopify.com',
    themeName: 'Symmetry',
    date: '2025-10-26',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart(){\n  document.documentElement.dispatchEvent(new CustomEvent('theme:cartchanged', { bubbles: true, cancelable: false, detail: { openDrawer: true } }));\n  document.querySelector(".cart-link").click();\n}\n</script>`
  },
  {
    id: '6',
    storeName: 'flexx-memory.myshopify.com',
    themeName: 'Electro Theme',
    date: '2025-10-07',
    author: 'Unknown',
    code: `async function wiseraddedtocart() {\n  if (window.innerWidth < 992) {\n    document.querySelector("#cart-message").addClass("is-open");\n  } else {\n    document.querySelector(".js-header-cart-icon--desktop").click();\n\n    try {\n      const res = await fetch("/?section_id=ajax-cart");\n      const html = await res.text();\n      const tempDiv = document.createElement("div");\n      tempDiv.innerHTML = html;\n      const ajaxCartSection = tempDiv.querySelector(\n        "#shopify-section-ajax-cart"\n      );\n      if (!ajaxCartSection) {\n        return;\n      }\n      const cartJSON = JSON.parse(\n        ajaxCartSection.querySelector("[data-cart-json]")?.innerHTML\n      );\n      const dropdownCartBody = document.querySelector(\n        "body .dropdown-cart .dropdown-cart_body"\n      );\n      if (dropdownCartBody) {\n        dropdownCartBody.innerHTML = ajaxCartSection.innerHTML;\n      }\n      const cartTotal = document.querySelector(".cart-total_price");\n      if (cartTotal && cartJSON.total_price != null) {\n        cartTotal.innerHTML = cartJSON.total_price.toCurrency();\n        window.Shopify?.theme?.sections?.instances?.[0]?.dropdownCart?.setItemCount(\n          cartJSON.item_count\n        );\n        const cartElement = document.querySelector(".js-header-dropdown-cart");\n        cartElement.setAttribute("data-cart-item-count", cartJSON.item_count);\n      }\n      window.Shopify?.theme?.sections?.instances?.[0].dropdownCart.container\n        .querySelectorAll(".js-cart-line-item")\n        .forEach(\n          window.Shopify?.theme?.sections?.instances?.[0].initDropdownCartLineItem.bind(\n            window.Shopify?.theme?.sections?.instances?.[0]\n          )\n        );\n    } catch (error) {\n      console.error("Error fetching cart data:", error);\n    }\n  }\n}\nwiseraddedtocart();`
  },
  {
    id: '7',
    storeName: 'cad71e-74.myshopify.com',
    themeName: 'PoseTheme',
    date: '2025-10-07',
    author: 'J',
    code: `function wiseraddedtocart() {\n  theme.miniCart.updateElements();\n  theme.miniCart.generateCart();\n}\nwiseraddedtocart()`
  },
  {
    id: '8',
    storeName: 'indiangoodsgenie.myshopify.com',
    themeName: 'Booster-7.1.4',
    date: '2025-10-07',
    author: 'D',
    code: `function wiseraddedtocart() {\n  $('.minicart__button--shopping-cart .minicart__label').trigger('click');\n}`
  },
  {
    id: '9',
    storeName: 'andy-evan.myshopify.com',
    themeName: 'Boost',
    date: '2025-10-07',
    author: 'D',
    code: `function wiseraddedtocart(){\n  window.SLIDECART_UPDATE()\n  window.SLIDECART_OPEN()\n}`
  },
  {
    id: '10',
    storeName: 'livingfitstore123.myshopify.com',
    themeName: 'Pursuit',
    date: '2025-10-06',
    author: 'D',
    code: `function wiserAddedToCart() {\n  theme.Cart.prototype._sidebarDrawerOpen();\n  theme.Cart.prototype._onProductAdded();\n}`
  },
  {
    id: '11',
    storeName: 'fb235c-92.myshopify.com',
    themeName: 'Divine',
    date: '2025-09-25',
    author: 'D',
    code: `<script>\nasync function wiseraddedtocart(){\n    const wsres = await fetch('/?section_id=cart-icon-bubble');\n    const wsText = await wsres.text();\n    const wshtml = document.createElement('div');\n    wshtml.innerHTML = wsText;\n    const wsnewBox = wshtml.querySelector('#shopify-section-cart-icon-bubble')?.innerHTML;\n    const cartIconElement = document.querySelector('#cart-icon-bubble'); // Fixed selector\n    if (cartIconElement) cartIconElement.innerHTML = wsnewBox;\n    document.querySelector("body .header__icon .cart-count-bubble").click();\n}\n</script>`
  },
  {
    id: '12',
    storeName: 'ozlifestyle-2.myshopify.com',
    themeName: 'Empire',
    date: '2025-09-23',
    author: 'D',
    code: `<script>\nfunction wiserAddedToCart(){\nfetch(\`\${window.Theme.routes.cart_url}.js\`)\n  .then(response => response.json())\n  .then(data => {\n    console.log('Cart data:', data);\n    const countEvent = new CustomEvent('cartcount:update', {\n      detail: data\n    });\n    window.dispatchEvent(countEvent);\n  })\n  .catch(error => console.error('Error updating cart:', error));\n}\n</script>`
  },
  {
    id: '13',
    storeName: 'pmc-jewellery.myshopify.com',
    themeName: 'Dawn',
    date: '2025-09-21',
    author: 'D',
    code: `<script>\nasync function wiserAddedToCart() {\n  try {\n    const wsres = await fetch('/?section_id=cart-icon-bubble');\n    const wsText = await wsres.text();\n    const wshtml = document.createElement('div');\n    wshtml.innerHTML = wsText;\n    const wsnewBox = wshtml.querySelector('#shopify-section-cart-icon-bubble')?.innerHTML;\n    const cartIconElement = document.querySelector('#cart-icon-bubble.header__icon--cart');\n    if (cartIconElement && wsnewBox) {\n      cartIconElement.innerHTML = wsnewBox;\n    }\n  } catch (error) {\n    console.error("Error in wiserAddedToCart:", error);\n  }\n}\n</script>`
  },
  {
    id: '14',
    storeName: '9bd82c-2.myshopify.com',
    themeName: 'Stiletto',
    date: '2025-09-16',
    author: 'D',
    code: `function wiseraddedtocart() {\n  $(".quick-cart__container").load(location.href + " .quick-cart__container>*", "");\n  setTimeout(function() {\n    $('body header a .icon-button.icon-button-header-shopping-cart').trigger('click');\n  }, 1500);\n}`
  },
  {
    id: '15',
    storeName: 'wojciechowskacosmetics.myshopify.com',
    themeName: 'Prestige',
    date: '2025-09-12',
    author: 'J',
    code: `async function wiseraddtocart() {                                \n  document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {\n  bubbles: true\n}));\n const cartDrawer = document.querySelector('cart-drawer');\n cartDrawer.show()\n }\nwiseraddtocart()`
  },
  {
    id: '16',
    storeName: 'mega-vitamins.myshopify.com',
    themeName: 'Ecomus',
    date: '2025-09-11',
    author: 'D',
    code: `<script>\n   function wiseraddedtocart() {\n      document.dispatchEvent(new CustomEvent("cart:refresh"));\n      document.querySelector(".hdt-site-nav_cart a").click();\n   }\n</script>`
  },
  {
    id: '17',
    storeName: 'wb-hbo.myshopify.com',
    themeName: 'Snow Blizzard',
    date: '2025-09-01',
    author: 'D',
    code: `<script>\n function wiseraddedtocart(){\n     new theme.CartDrawer();\n     $(".js-drawer-open-cart span").trigger("click");\n   }\n</script>`
  },
  {
    id: '18',
    storeName: 'universal-parks.myshopify.com',
    themeName: 'Dawn',
    date: '2025-09-01',
    author: 'D',
    code: `<script>\n async function wiseraddedtocart() {\n    const wsres = await fetch('/?section_id=cart-icon-bubble');\n    const wsText = await wsres.text();\n    const wshtml = document.createElement('div');\n    wshtml.innerHTML = wsText;\n    const wsnewBox = wshtml.querySelector('#shopify-section-cart-icon-bubble')?.innerHTML;\n    const cartIconElement = document.querySelector('#cart-icon-bubble.header__icon--cart');\n    cartIconElement.innerHTML = wsnewBox;\n    const wsrescart = await fetch('/?section_id=cart-drawer');\n    const wstextcart = await wsrescart.text();\n    const wshtmlcart = document.createElement('div');\n    wshtmlcart.innerHTML = wstextcart;\n    const wsnewBoxCart = wshtmlcart.querySelector('.drawer__inner').innerHTML;\n    document.querySelector('.drawer__inner').innerHTML = wsnewBoxCart;\n    const wsopener = document.querySelector('cart-drawer');\n    wsopener.open();\n    document.querySelector('cart-drawer').classList.remove('is-empty');\n  }\n</script>`
  },
  {
    id: '19',
    storeName: 'disney-hulu.myshopify.com',
    themeName: 'Snow Blizzard',
    date: '2025-08-20',
    author: 'D',
    code: `function wiserAddedToCart() {\n  if (!theme.cartDrawer && typeof theme.CartDrawer === 'function') {\n    theme.cartDrawer = new theme.CartDrawer();\n  }\n  // cartDrawer logic\n  fetch('/cart.js')\n    .then(response => response.json())\n    .then(cart => {\n      if (theme.cartDrawer && theme.cartDrawer.updateSuccess) {\n        theme.cartDrawer.updateSuccess(cart);\n        theme.cartDrawer.drawer.open();\n      }\n    });\n}`
  },
  {
    id: '20',
    storeName: '38dd0b-3.myshopify.com',
    themeName: 'Dawn',
    date: '2025-08-20',
    author: 'D',
    code: `function wiseraddedtocart(){\nconst cartIcon = $("#cart-icon-bubble")[0];\nif (cartIcon) cartIcon.click();\n  monster_refresh();\n}`
  },
  {
    id: '21',
    storeName: 'turner-engineering.myshopify.com',
    themeName: 'Athens',
    date: '2025-08-20',
    author: 'D',
    code: `function wiseraddedtocart(){\n  const wscart = document.querySelector("mini-cart");\n  wscart.updateQuantity();\n  wscart.open();\n}`
  },
  {
    id: '22',
    storeName: 'chefs-mandala-gourmet-store.myshopify.com',
    themeName: 'Dawn',
    date: '2025-07-03',
    author: 'N',
    code: `async function wiseraddedtocart() {\n    const wsres = await fetch('/?section_id=cart-icon-bubble');\n    const wsText = await wsres.text();\n    const wshtml = document.createElement('div');\n    wshtml.innerHTML = wsText;\n    const wsnewBox = wshtml.querySelector('#shopify-section-cart-icon-bubble')?.innerHTML;\n    const cartIconElement = document.querySelector('#cart-icon-bubble.header__icon--cart');\n    cartIconElement.innerHTML = wsnewBox;\n    const wsrescart = await fetch('/?section_id=cart-drawer');\n    const wstextcart = await wsrescart.text();\n    const wshtmlcart = document.createElement('div');\n    wshtmlcart.innerHTML = wstextcart;\n    const wsnewBoxCart = wshtmlcart.querySelector('.drawer__inner').innerHTML;\n    document.querySelector('.drawer__inner').innerHTML = wsnewBoxCart;\n    const wsopener = document.querySelector('cart-drawer');\n    wsopener.open();\n    document.querySelector('cart-drawer').classList.remove('is-empty');\n  }\n  wiseraddedtocart()`
  },
  {
    id: '23',
    storeName: 'haveda-uk.myshopify.com',
    themeName: 'Dawn',
    date: '2025-07-03',
    author: 'Y',
    code: `async function wiserAddedToCart() {\nconst wsres = await fetch('/?section_id=cart-icon-bubble');\n    const wsText = await wsres.text();\n   const wshtml = document.createElement('div');\n      wshtml.innerHTML = wsText;\n    const wsnewBox = wshtml.querySelector('#shopify-section-cart-icon-bubble')?.innerHTML;\nconst cartIconElement = document.querySelector('#cart-icon-bubble.header__icon--cart');\ncartIconElement.innerHTML = wsnewBox;\n}`
  },
  {
    id: '24',
    storeName: 'flexpawz-2.myshopify.com',
    themeName: 'Dawn',
    date: '2025-07-03',
    author: 'D',
    code: `function wiseraddedtocart(){\nconst cartIcon = $("#cart-icon-bubble")[0];\nif (cartIcon) cartIcon.click();\n  monster_refresh();\n}`
  },
  {
    id: '25',
    storeName: 'cad71e-74.myshopify.com',
    themeName: 'PoseTheme',
    date: '2025-07-03',
    author: 'Y',
    code: `function wiseraddedtocart() {\n  theme.miniCart.updateElements();\n  theme.miniCart.generateCart();\n}\n\nsetTimeout(function () {\n  var $wsInit = 0;\n  var oldcount = 0;\n  var $wsInterval = setInterval(function () {\n    var $wsDrawerDivCnt = document.querySelectorAll('body div.evm-drawer-main div').length;\n    var newCount = document.querySelector('.mini-cart-header .js-cart-count').textContent;\n    if ($wsDrawerDivCnt == 16 && $wsInit == 0 && oldcount != newCount) {\n      $wsInit = 1;\n      window.WISER_INIT('cart', 1);\n      oldcount = newCount;\n      setTimeout(function () {\n        $wsInit = 0;\n      }, 3000);\n    }\n  }, 100);\n}, 3000);`
  },
  {
    id: '26',
    storeName: 'eyb5bj-dr.myshopify.com',
    themeName: 'Blockshop',
    date: '2025-06-27',
    author: 'Y',
    code: `<script>\nasync function wiseraddedtocart() {\n  const wsres = await fetch("/?section_id=cart-drawer");\n  const wstext = await wsres.text();\n  const wshtml = document.createElement("div");\n  wshtml.innerHTML = wstext;\n  const wsnewBox = wshtml.querySelector("cart-element").innerHTML;\n  document.querySelector("cart-element").innerHTML = wsnewBox;\n  const viewport = document.querySelector(".layout--viewport");\n  if (viewport) {\n    viewport.setAttribute("data-cart-empty", "false");\n  }\n  window.trigger("theme:drawer:open", {\n    side: "right",\n    view: "cart-drawer",\n    trigger: "",\n  });\n  window.trigger("theme:transition:reload:cart-drawer");\n  window.Cart.updateTotals("updateTotals");\n} </script>`
  },
  {
    id: '27',
    storeName: 'hi8ahp-jn.myshopify.com',
    themeName: 'Impulse',
    date: '2025-06-25',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart() {\n  new theme.CartDrawer();\n  $(".js-drawer-open-cart span").trigger("click");\n}\n </script>`
  },
  {
    id: '28',
    storeName: 'signify-india.myshopify.com',
    themeName: 'Lampi',
    date: '2025-06-25',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart() {\n  let wsFlag = 0;\n  if (!document.querySelector(".mini-cart-bottom.enj-minicart-ajax .prod ")) {\n    if (wsFlag == 0) {\n      wsFlag = 1;\n      window.REFRESH_CART(true);\n    }\n    window.refreshCart(true);\n    window.OPEN_CART();\n  } else {\n    window.refreshCart(true);\n    window.OPEN_CART();\n  }\n}\n </script>`
  },
  {
    id: '29',
    storeName: 'somethings-brewing-store.myshopify.com',
    themeName: 'Hyper',
    date: '2025-06-25',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart() {\n  const wscart11 = document.querySelector("cart-count");\n  if (wscart11 && wscart11.hasAttribute("hidden")) {\n    wscart11.removeAttribute("hidden");\n  }\n  const wscart = document.querySelector("cart-drawer");\n if (wscart && typeof wscart.onCartRefresh === "function") {\n    wscart.onCartRefresh();\n  }\n  wscart.show();\n}\n </script>`
  },
  {
    id: '30',
    storeName: 'american-cornhole-association.myshopify.com',
    themeName: 'Focal',
    date: '2025-06-12',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart() {\n  document.documentElement.dispatchEvent(\n    new CustomEvent("cart:refresh", {\n      bubbles: true,\n      detail: {\n        openMiniCart: window.themeVariables.settings.cartType === "drawer",\n      },}));\n  // Theme based code\n  $.getJSON("/cart.js", function (cart) {\n    var ws_item_count = cart.item_count;\n    $(".header__cart-count").text(ws_item_count);\n  });\n}\n\nvar $wsInit = 0;\nvar $wsInterval = setInterval(function () {\n  var $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\n  var wsChkAttr = $("cart-drawer").attr("open");\n  if (\n    typeof wsChkAttr !== "undefined" &&\n    wsChkAttr !== false &&\n    $wsDrawerDivCnt == 8 &&\n    $wsInit == 0\n  ) {\n    $wsInit = 1;\n    window.WISER_INIT("cart", 1);\n    setTimeout(function () {\n      $wsInit = 0;\n    }, 1000);}\n}, 100);\n </script>`
  },
  {
    id: '31',
    storeName: 'azariabrand.myshopify.com',
    themeName: 'Shella',
    date: '2025-06-12',
    author: 'D',
    code: `<script>\n  function wiseraddedtocart() {\n        $("body .header__counter")[0].click();\n  }\n </script>`
  },
  {
    id: '32',
    storeName: 'lashv-us.myshopify.com',
    themeName: 'Minimog - OS 2.0',
    date: '2025-06-06',
    author: 'D',
    code: `<script>\n  function wiseraddedtocart(){\n  const wscart = document.querySelector('m-cart-drawer');\n  wscart.onCartDrawerUpdate();\n  wscart.open();\n  }\nsetTimeout(function () {\n  var $wsInit = 0;\n  var oldcount = 0;\n  var $wsInterval = setInterval(function () {\n    var $wsDrawerDivCnt = document.querySelectorAll('body div.evm-drawer-main div').length;\n    var newCount = document.querySelector('.m-cart-count-bubble').textContent;\n    if ($wsDrawerDivCnt == 8 && $wsInit == 0 && oldcount != newCount) {\n      $wsInit = 1;\n      window.WISER_INIT('cart', 1);\n      oldcount = newCount;\n      setTimeout(function () {\n        $wsInit = 0;\n      }, 3000);\n    }\n  }, 100);\n }, 3000);\n</script>`
  },
  {
    id: '33',
    storeName: '2dffa4.myshopify.com',
    themeName: 'Testament',
    date: '2025-05-29',
    author: 'D',
    code: `<script>\n  function wiseraddedtocart(){\n     const cartDrawer11 = document.querySelector('.cart-drawer');\n    cartDrawer11?.openDialog?.();\n   const cartDrawer22 = document.querySelector('cart-items');\ncartDrawer22?.refreshCart();\n  }  \nsetTimeout(function () {\n  var $wsInit = 0\n  var oldcount = 0\n  var $wsInterval = setInterval(function () {\n    var $wsDrawerDivCnt = document.querySelectorAll('body div.evm-drawer-main div').length\n    var newCount = document.querySelector('.evm_wiser_count').textContent\n    if ($wsDrawerDivCnt == 8 && $wsInit == 0 && oldcount != newCount) {\n      $wsInit = 1\n      window.WISER_INIT('cart', 1)\n      oldcount = newCount\n      setTimeout(function () {\n        $wsInit = 0\n      }, 3000)\n    }\n  }, 00)\n}, 4000)\n</script>`
  },
  {
    id: '34',
    storeName: 'everything-crochet-shop.myshopify.com',
    themeName: 'Primavera',
    date: '2025-05-30',
    author: 'D',
    code: `<script>\n  function wiseraddedtocart(){\n     const cartDrawer11 = document.querySelector('.cart-drawer');\n    cartDrawer11?.openDialog?.();\n   const cartDrawer22 = document.querySelector('cart-items');\ncartDrawer22?.refreshCart();\n  }  \nsetTimeout(function () {\n  var $wsInit = 0\n  var oldcount = 0\n  var $wsInterval = setInterval(function () {\n    var $wsDrawerDivCnt = document.querySelectorAll('body div.evm-drawer-main div').length\n    var newCount = document.querySelector('.evm_wiser_count').textContent\n    if ($wsDrawerDivCnt == 8 && $wsInit == 0 && oldcount != newCount) {\n      $wsInit = 1\n      window.WISER_INIT('cart', 1)\n      oldcount = newCount\n      setTimeout(function () {\n        $wsInit = 0\n      }, 3000)\n    }\n  }, 00)\n}, 4000)\n</script>`
  },
  {
    id: '35',
    storeName: 'gtworldde.myshopify.com',
    themeName: 'Be Yours',
    date: '2025-01-05',
    author: 'D',
    code: `<script>\n   async function wiseraddedtocart() {\n  const wsopener = document.querySelector("cart-drawer");\n  wsopener.openMenuDrawer();\n  const wsres = await fetch("/?section_id=mini-cart");\n  const wstext = await wsres.text();\n  const wshtml = document.createElement("div");\n  wshtml.innerHTML = wstext;\n  const wsnewBox =                   wshtml.querySelector(".mini-cart__inner").innerHTML; \n  document.querySelector(".mini-cart__inner").innerHTML = wsnewBox;\n  document.querySelector(".mini-cart").classList.remove("is-empty");\n}\n</script>`
  },
  {
    id: '36',
    storeName: 'bodegas-ferrera.myshopify.com',
    themeName: 'wpbingo',
    date: '2025-04-30',
    author: 'D',
    code: `<script>\n  function wiseraddedtocart(){\n    ajaxCart.load();\n    $('body').addClass('drawer--open');\n    $('.js-drawer-close').on('click', function() {\n    $('body').removeClass('drawer--open');\n    });\n  }\n</script>`
  },
  {
    id: '37',
    storeName: 'softambient.myshopify.com',
    themeName: 'Minimog - OS 2.0',
    date: '2025-04-09',
    author: 'D',
    code: `<script>\n  function wiseraddedtocart(){\n  const wscart = document.querySelector('m-cart-drawer');\n  wscart.onCartDrawerUpdate();\n  wscart.open();\n  }\n</script>`
  },
  {
    id: '38',
    storeName: 'finemodesty.myshopify.com',
    themeName: 'dawn',
    date: '2025-04-08',
    author: 'D',
    code: `function wiseraddedtocart(){\n   $("#ws_CartDrawer").load(location.href+" #ws_CartDrawer>*","");\n    setTimeout(function () {\n      $.getJSON('/cart.js', function(cart) {\n        var ws_item_count = cart.item_count\n        $(".cart-count-bubble").remove();\n        $("#cart-icon-bubble").append('<div class="cart-count-bubble"><span aria-hidden="true">'+ws_item_count+'</span><span class="visually-hidden">'+ws_item_count+' item</span></div>');\n        $("body .header__icons #cart-icon-bubble")[0].click();\n      });\n    }, 1000);\n}`
  },
  {
    id: '39',
    storeName: 'littleweststreet.myshopify.co',
    themeName: 'Prestige',
    date: '2025-04-04',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart(){\n  document.documentElement.dispatchEvent(new CustomEvent('product:added', {\n            bubbles: true,\n            detail: {\n         quantity: 1\n            }\n          }));\n}\n </script>`
  },
  {
    id: '40',
    storeName: '1-itemisrael.myshopify.com',
    themeName: 'Prestige',
    date: '2025-04-04',
    author: 'D',
    code: `<script>\n    function wiseraddedtocart() {    \n    document.dispatchEvent(new CustomEvent('product:added', {\n        bubbles: true,\n      detail: {}\n    }));\n  }\n let $wsInit = 0;\n    setInterval(function() {\n     \n    $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\nconsole.log($wsDrawerDivCnt , "$wsDrawerDivCnt")\nconst cartDrawer11 = document.querySelector('.cart-drawer');\nif (cartDrawer11.open  && $wsDrawerDivCnt == 8 && $('#cart-drawer').css('display') == 'block' && $wsInit == 0) {\n      window.WISER_INIT('cart',1);\n       setTimeout(function () {\n      $wsInit = 0;\n    }, 3000);\n    }\n  }, 500);\n  </script>`
  },
  {
    id: '41',
    storeName: 'voltage-staging.myshopify.com',
    themeName: 'Prestige',
    date: '2025-04-04',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart(){\n  document.documentElement.dispatchEvent(new CustomEvent('product:added', {\n  bubbles: true,\n  detail: {      \n  quantity: 1\n}\n}));\n}\n    </script>`
  },
  {
    id: '42',
    storeName: '650226-3.myshopify.co',
    themeName: 'Origin',
    date: '2025-04-03',
    author: 'Y',
    code: `<script>\n     async function wiseraddedtocart(){\nconst wsopener = document.querySelector('cart-drawer')\n  wsopener.open()\n  const wsres = await fetch('/?section_id=cart-drawer')\n  const wstext = await wsres.text()\n  const wshtml = document.createElement('div')\n  wshtml.innerHTML = wstext\n  const wsnewBox = wshtml.querySelector('.drawer').innerHTML\n  document.querySelector('.drawer').innerHTML = wsnewBox\n  document.querySelector('.drawer').classList.remove('is-empty')\nundefined\n      }\n \nvar $wsInit = 0;\nvar $wsCartCntOld = 0;\nvar $wsInterval = setInterval(function () {\n  var $wsCartCnt = $("body .cart-count-bubble span[aria-hidden='true']").text();\n  if (\n    document.querySelector("cart-drawer").classList.contains("active") &&\n    $wsCartCnt != $wsCartCntOld &&\n    $wsInit == 0\n  ) {\n    $wsCartCntOld = $wsCartCnt;\n    $wsInit = 1;\n    window.WISER_INIT("cart", 1);\n    setTimeout(function () {\n      $wsInit = 0;\n    }, 1000);\n  }\n}, 500);\n    </script>`
  },
  {
    id: '43',
    storeName: 'voltage-staging.myshopify.com',
    themeName: 'Electro',
    date: '2025-02-10',
    author: 'D',
    code: `async function wiseraddedtocart() {\n  const wsopener = document.querySelector('sht-cart-drwr')\n  wsopener.openDrawer()\n  const wsres = await fetch('/?section_id=cart-drawer')\n  const wstext = await wsres.text()\n  const wshtml = document.createElement('div')\n  wshtml.innerHTML = wstext\n  const wsnewBox = wshtml.querySelector('.drawer__wrapper').innerHTML\n  document.querySelector('.drawer__wrapper').innerHTML = wsnewBox\n  document.querySelector('.drawer__wrapper').classList.remove('is-empty')\n}`
  },
  {
    id: '44',
    storeName: 'intrepid-6309.myshopify.com',
    themeName: 'Bullet',
    date: '2025-02-14',
    author: 'Y',
    code: `function wiseraddedtocart() {\n  setTimeout(() => {\n    const wsopener = document.querySelector("cart-drawer");\n    if (wsopener) {\n      wsopener.show();\n      console.log("Cart drawer shown");\n    } else {\n      console.error("cart-drawer not found!");\n    }\n  }, 500);`
  },
  {
    id: '45',
    storeName: 'gs13gg-za.myshopify.com',
    themeName: 'Concept',
    date: '2025-03-20',
    author: 'Y',
    code: `async function wiseraddedtocart() {\n  const wsopener = document.querySelector('cart-drawer')\n  if (window.cartItemsVal.length > 0) {\n    wsopener.refresh()\n  } else {\n    const wsres = await fetch('/?section_id=cart-drawer')\n    const wstext = await wsres.text()\n    const wshtml = document.createElement('div')\n    wshtml.innerHTML = wstext\n    const wsnewBox = wshtml.querySelector('.drawer__content').innerHTML\n    document.querySelector('.drawer__content').innerHTML = wsnewBox\n    const cartLink = document.querySelector('#cart-icon-bubble')\n  }\n  wsopener.open()\n}\nsetTimeout(function () {\n  var $wsInit = 0\n  var oldcount = 0\n  var $wsInterval = setInterval(function () {\n    var $wsDrawerDivCnt = document.querySelectorAll('body div.evm-drawer-main div').length\n    var newCount = document.querySelector('.evm_wiser_count').textContent\n    if ($wsDrawerDivCnt == 8 && $wsInit == 0 && oldcount != newCount) {\n      $wsInit = 1\n      window.WISER_INIT('cart', 1)\n      oldcount = newCount\n      setTimeout(function () {\n        $wsInit = 0\n      }, 3000)\n    }\n  }, 00)\n}, 5000)`
  },
  {
    id: '46',
    storeName: 'royale-lighting.myshopify.com',
    themeName: 'Concept',
    date: '2025-03-25',
    author: 'D',
    code: `function wiseraddedtocart() {\n  const wsopener = document.querySelector('cart-drawer')\n  wsopener.onCartRefresh()\n  wsopener.show()\n  document.querySelectorAll('.evm_wiser_count').forEach(el => el.removeAttribute('hidden'))\n}`
  },
  {
    id: '47',
    storeName: 'n2-interior.myshopify.com',
    themeName: 'Bullet',
    date: '2025-03-25',
    author: 'Y',
    code: `function wiseraddedtocart(){\n window.liquidAjaxCart.update()\n     const wscartdrawer = document.querySelector("coretex-dialog")\n     wscartdrawer.open();\n }`
  },
  {
    id: '48',
    storeName: 'ugaoo-store.myshopify.com',
    themeName: 'Be Yours',
    date: '2025-03-26',
    author: 'D',
    code: `async function wiseraddedtocart(){\n  const wsopener = document.querySelector("cart-drawer");\n  wsopener.openMenuDrawer();\n  const wsres = await fetch("/?section_id=mini-cart");\n  const wstext = await wsres.text();\n  const wshtml = document.createElement("div");\n  wshtml.innerHTML = wstext;\n  const wsnewBox = wshtml.querySelector(".mini-cart__inner").innerHTML;\n  document.querySelector(".mini-cart__inner").innerHTML = wsnewBox;\n  document.querySelector(".mini-cart").classList.remove("is-empty");\n}\n  var $wsInit = 0;\nvar $wsInterval = setInterval(function() {\n  var $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\n  var wsChkAttr = $('.cart-drawer-container').attr('open');\n  if (wsChkAttr !== false && $wsDrawerDivCnt == 8 && $wsInit == 0) {\n    $wsInit = 1;\n    window.WISER_INIT('cart',1);\n    setTimeout(function () {\n      $wsInit = 0;\n    }, 3000);\n  }\n}, 100);`
  },
  {
    id: '49',
    storeName: '1nruwb-jm.myshopify.com',
    themeName: 'dawn',
    date: '2025-03-05',
    author: 'D',
    code: `function wiseraddedtocart(){\n  $("#ws_CartDrawer").load(location.href+" #ws_CartDrawer>*","");\n    setTimeout(function () {\n      $.getJSON('/cart.js', function(cart) {\n        var ws_item_count = cart.item_count\n        $(".cart-count-bubble").remove();\n        $("#cart-icon-bubble").append('<div class="cart-count-bubble"><span aria-hidden="true">'+ws_item_count+'</span><span class="visually-hidden">'+ws_item_count+' item</span></div>');\n        $("body .header__icon #cart-icon-bubble")[0].click();\n      });\n    }, 1000);\n}`
  },
  {
    id: '50',
    storeName: 'baa2ce-78.myshopify.com',
    themeName: 'Ella',
    date: '2025-01-29',
    author: 'D',
    code: `// Create wsHaloJs variable in theme.js file and assign value on this variable halo variable value\n\nfunction wiseraddedtocart() {\n  $.getJSON("/cart.js", function (cart) {\n    if (window.page_name === "cart") {\n      wsHaloJs.updateCart(cart);\n    } else {\n      wsHaloJs.updateSidebarCart(cart);\n    }\n    document.querySelector('a[href="/cart"]').click();\n  });\n}`
  },
  {
    id: '51',
    storeName: 'colorshow-pk.myshopify.com',
    themeName: 'Debut',
    date: '2025-01-09',
    author: 'Y',
    code: `function wiseraddedtocart() {\n  adjustCartDropDown()\n  if (!$('.cart-display #cart-container').hasClass('innew')) {\n    $('.cart-display #cardawnt-container').addClass('innew')\n    $('.cart-display .cart-title').addClass('collapsed')\n    $('.cart-display .cart-title').attr('aria-expanded', 'true')\n    $('.cart-display #cart-container').css('height', '')\n  }\n}`
  },
  {
    id: '52',
    storeName: 'kristielight.myshopify.com',
    themeName: 'Pink Paradise',
    date: '2025-01-08',
    author: 'Y',
    code: `/* file m changes h\njquery.interact-function.js\nline number : 3559\nwiserSell: function(){\n          ShowCart();\n        }\nline number: 2434\nalsoShopify.wiserSell(); */\nfunction wiseraddedtocart(){\n    window.aloShopify.wiserSell()\n    $(".mini-cart.push_side.header-icon").trigger("click")\n  }`
  },
  {
    id: '53',
    storeName: 'ensojewellery.myshopify.com',
    themeName: 'Wpbingo',
    date: '2025-01-09',
    author: 'D',
    code: `function wiseraddedtocart(){\n          ajaxCart.load();\n          $('body').addClass('drawer--open');\n          $('.js-drawer-close').on('click', function() {\n            $('body').removeClass('drawer--open');\n          });\n         }`
  },
  {
    id: '54',
    storeName: 'colorshow-pk.myshopify.com',
    themeName: 'Debut',
    date: '2024-12-18',
    author: 'Y',
    code: `function wiseraddedtocart(){\n  adjustCartDropDown();\n if(!$(".cart-display #cart-container").hasClass('innew')){\n      $(".cart-display #cart-container").addClass('innew');\n      $(".cart-display .cart-title").addClass('collapsed');\n      $(".cart-display .cart-title").attr("aria-expanded", "true");\n      $(".cart-display #cart-container").css('height', '');\n    }\n}`
  },
  {
    id: '55',
    storeName: 'ca490c-bb.myshopify.com',
    themeName: 'Impact',
    date: '2024-12-18',
    author: 'D',
    code: `function wiseraddedtocart() {\n  const wsopener = document.querySelector("cart-drawer");\n  wsopener._onCartRefreshListener();\n  wsopener.show();\n  fetch("/cart.js")\n    .then((res) => res.json())\n    .then((cartData) => {\n      const itemCount = cartData.item_count || 0;\n      document.dispatchEvent(\n        new CustomEvent("cart:change", {\n          detail: { cart: { item_count: itemCount } },\n        })\n      );\n    });\n}`
  },
  {
    id: '56',
    storeName: 'organic-olivia.myshopify.com',
    themeName: 'be yours',
    date: '2024-12-18',
    author: 'Y',
    code: `async function wiseraddedtocart() {\n  const wsopener = document.querySelector("cart-drawer");\n  wsopener.openMenuDrawer();\n  const wsres = await fetch("/?section_id=mini-cart");\n  const wstext = await wsres.text();\n  const wshtml = document.createElement("div");\n  wshtml.innerHTML = wstext;\n  const wsnewBox = wshtml.querySelector(".mini-cart__inner").innerHTML;\n  document.querySelector(".mini-cart__inner").innerHTML = wsnewBox;\n  document.querySelector(".mini-cart").classList.remove("is-empty");\n}`
  },
  {
    id: '57',
    storeName: 'maxxusindustries.myshopify.com',
    themeName: 'Dawn',
    date: '2024-12-18',
    author: 'D',
    code: `function wiseraddedtocart() {\n    const wscart = document.querySelector('cart-notification');\n   wscart.renderCartContent();\n   wscart.open();\n    }`
  },
  {
    id: '58',
    storeName: 'another-level-beauty-supply-llc.myshopify.com',
    themeName: 'Ella',
    date: '2024-12-13',
    author: 'D',
    code: `// Create wsHaloJs variable in theme.js file and assign value on this variable halo variable value\n\nfunction wiseraddedtocart() {\n  $.getJSON("/cart.js", function (cart) {\n    if (window.page_name === "cart") {\n      wsHaloJs.updateCart(cart);\n    } else {\n      wsHaloJs.updateSidebarCart(cart);\n    }\n    document.querySelector('a[href="/cart"]').click();\n  });\n}`
  },
  {
    id: '59',
    storeName: '179bd3.myshopify.com',
    themeName: 'Kalles',
    date: '2024-12-12',
    author: 'Y',
    code: `function wiseraddedtocart(){\n         window.T4SThemeSP.Cart.getToFetch();\n  $(".t4s-site-nav__cart svg").trigger("click");\n     }`
  },
  {
    id: '60',
    storeName: 'q5r1im-rd.myshopify.com',
    themeName: 'Shrine PRO',
    date: '2024-12-11',
    author: 'D',
    code: `async function wiseraddedtocart() {\n  $.getJSON("/cart.js", function (cart) {\n    var ws_item_count = cart.item_count;\n    $(".cart-count-bubble").remove();\n    $("#cart-icon-bubble").append(\n      '<div class="cart-count-bubble"><span aria-hidden="true">' +\n        ws_item_count +\n        '</span><span class="visually-hidden">' +\n        ws_item_count +\n        " item</span></div>"\n    );\n  });\n  const wsDrawerSelector = document.querySelector("cart-drawer");\n  const wsres = await fetch("/?section_id=cart-drawer");\n  const wstext = await wsres.text();\n  const wshtml = document.createElement("div");\n  wshtml.innerHTML = wstext;\n  const wsnewBox = wshtml.querySelector(".drawer__inner").innerHTML;\n  document.querySelector(".drawer__inner").innerHTML = wsnewBox;\n  document.querySelector(".drawer").classList.remove("is-empty");\n  const cartLink = document.querySelector("#cart-icon-bubble");\n  wsDrawerSelector.open();\n}`
  },
  {
    id: '61',
    storeName: 'zenescope.myshopify.com',
    themeName: 'Xtra',
    date: '2024-12-03',
    author: 'Y',
    code: `function wiseraddedtocart() {\n  window.ajaxCart.init();\n  window.ajaxCart.load();\n}\n\n// Theme based code\n$(document).ready(function () {\n  var $wsInit = 0;\n  let $wsCartCntOld = 0;\n\n  var $wsInterval = setInterval(function () {\n    $wsDrawerDivCnt = $("body div.evm-drawer-main > div").length;\n    let $wsCartCntnew = $(".evm_wiser_count").text();\n    if (\n      $("#cart").attr("aria-hidden") === "false" &&\n      $wsInit == 0 &&\n      $wsCartCntnew != $wsCartCntOld &&\n      $wsDrawerDivCnt == 8\n    ) {\n      $wsCartCntOld = $wsCartCntnew;\n      $wsInit = 1;\n      window.WISER_INIT("cart", 1);\n      setTimeout(function () {\n        $wsInit = 0;\n      }, 3000);\n    }\n  }, 1000);\n});`
  },
  {
    id: '62',
    storeName: 'metapod-com.myshopify.com',
    themeName: 'Impact',
    date: '2024-12-03',
    author: 'D',
    code: `function  wiseraddedtocart() {\n  const wsopener = document.querySelector("cart-drawer")\n    wsopener._onCartRefreshListener();\n wsopener.show()\n  const cartCount = document.querySelector("cart-count");\nif (cartCount.style.opacity === "0" || !cartCount.style.opacity) {\n  cartCount.style.opacity = "1";\n  } \n  // Theme based code\n  var $wsInit = 0;\nvar $wsInterval = setInterval(function() {\n  var $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\n  var wsChkAttr = $('cart-drawer').attr('open');\n  if (typeof wsChkAttr !== 'undefined' && wsChkAttr !== false && $wsDrawerDivCnt == 8 && $wsInit == 0) {\n    $wsInit = 1;\n    window.WISER_INIT('cart',1);\n    setTimeout(function () {\n      $wsInit = 0;\n    }, 3000);\n  }\n}, 100);`
  },
  {
    id: '63',
    storeName: 'soulandmore.myshopify.com',
    themeName: 'Sense',
    date: '2024-12-02',
    author: 'Y',
    code: `async function wiseraddtocart(){\n        const wsDrawerSelector = document.querySelector("cart-drawer");\n     const res = await fetch("/?section_id=cart-drawer");\n       const text = await res.text(); console.log(text , "inside")\n        const html = document.createElement("div");\n    html.innerHTML = text;\n        const newBox = html.querySelector(".drawer__inner").innerHTML;\n    document.querySelector(".drawer__inner").innerHTML = newBox;\n   document.querySelector(".drawer").classList.remove("is-empty");\n   const cartLink = document.querySelector('#cart-icon-bubble');\n    wsDrawerSelector.open()\n      }`
  },
  {
    id: '64',
    storeName: 'zoelle-fit.myshopify.com',
    themeName: 'Impulse',
    date: '2024-11-27',
    author: 'D',
    code: `function wiseraddedtocart() {\n  new theme.CartDrawer();\n  $(".js-drawer-open-cart span").trigger("click");\n}`
  },
  {
    id: '65',
    storeName: 'warnerbrothers-shop.myshopify.com',
    themeName: 'Impulse',
    date: '2024-11-27',
    author: 'D',
    code: `function wiseraddedtocart() {\n  new theme.CartDrawer();\n  $(".js-drawer-open-cart span").trigger("click");\n}`
  },
  {
    id: '66',
    storeName: 'startrek-shop.myshopify.com',
    themeName: 'Avalanche',
    date: '2024-11-27',
    author: 'Y',
    code: `function wiseraddedtocart(){\n      setTimeout(function () {\n      $.getJSON('/cart.js', function(cart) {\n        var ws_item_count = cart.item_count\n        $(".cart-count-bubble").remove();\n        $("#cart-icon-bubble").append('<div class="cart-count-bubble"><span aria-hidden="true">'+ws_item_count+'</span><span class="visually-hidden">'+ws_item_count+' item</span></div>');\n        $("body .header__icons #cart-icon-bubble")[0].click();\n      });\n    }, 1000);\n}`
  },
  {
    id: '67',
    storeName: 'nbcuniversal.myshopify.com',
    themeName: 'Avalanche',
    date: '2024-11-27',
    author: 'D',
    code: `function wiseraddedtocart(){\n    setTimeout(function () {\n      $.getJSON('/cart.js', function(cart) {\n        var ws_item_count = cart.item_count\n        $(".cart-count-bubble").remove();\n        $("#cart-icon-bubble").append('<div class="cart-count-bubble"><span aria-hidden="true">'+ws_item_count+'</span><span class="visually-hidden">'+ws_item_count+' item</span></div>');\n        $("body .header__icons #cart-icon-bubble")[0].click();\n        $('#shopify-section-cart-drawer .my-cart, .cart-close-button, .cart-drawer-overlay').addClass("open");\n        window.postMessage({ type: 'cart_drawer', action: "open"}, '*');\n      });\n    }, 1000);\n}`
  },
  {
    id: '68',
    storeName: 'fox-pos.myshopify.com',
    themeName: 'dawn',
    date: '2024-11-25',
    author: 'D',
    code: `function wiseraddedtocart(){\n      $("#ws_CartDrawer").load(location.href+" #ws_CartDrawer>*","");\n    setTimeout(function () {\n      $.getJSON('/cart.js', function(cart) {\n        var ws_item_count = cart.item_count\n        $(".cart-count-bubble").remove();\n        $("#cart-icon-bubble").append('<div class="cart-count-bubble"><span aria-hidden="true">'+ws_item_count+'</span><span class="visually-hidden">'+ws_item_count+' item</span></div>');\n        $("body .header__icons #cart-icon-bubble")[0].click();\n      });\n    }, 1000);\n}`
  },
  {
    id: '69',
    storeName: 'poppys-of-atlanta.myshopify.com',
    themeName: 'Testament',
    date: '2024-11-25',
    author: 'Y',
    code: `function wiseraddedtocart(){\n      let ws_drawerConfig = document.getElementById('cart-config');\n        ws_drawerConfig = JSON.parse(config.innerHTML || '{}');\n      Shopify.theme.ajaxCart.showDrawer(ws_drawerConfig);\n     \n      }\n     \n      var $wsInit = 0;\n          let $wsCartCntOld = 0;\n          var $wsInterval = setInterval(function() {\n          $wsDrawerDivCnt = $("body div.evm-drawer-main > div").length;\n          let $wsCartCntnew = $('.cart-links__link-cart .button-as-link .js-cart-count').text();\n           \n          if ($("body .slideout__drawer-right.mini-cart").hasClass("slideout--active") && $wsInit == 0  && $wsCartCntnew != $wsCartCntOld) {\n            $wsCartCntOld = $wsCartCntnew;\n            $wsInit = 1;\n            window.WISER_INIT('cart',1);\n            console.log(" 22222 ")\n            setTimeout(function () {\n              $wsInit = 0;\n            }, 3000);\n          }\n      }, 100);`
  },
  {
    id: '70',
    storeName: 'vcbs-yellowstone.myshopify.com',
    themeName: 'Avalanche',
    date: '2024-11-21',
    author: 'Y',
    code: `async function wiseraddedtocart() {    \n  const wsres = await fetch('/?section_id=cart-icon-bubble');\n    const wsText = await wsres.text();\n   const wshtml = document.createElement('div');\n      wshtml.innerHTML = wsText;\n    const wsnewBox = wshtml.querySelector('#shopify-section-cart-icon-bubble')?.innerHTML;\nconst cartIconElement = document.querySelector('#cart-icon-bubble.header__icon');\ncartIconElement.innerHTML = wsnewBox;\n  const wsrescart = await fetch("/?section_id=cart-drawer");\n  const wstextcart = await wsrescart.text();\n  const wshtmlcart = document.createElement("div");\n  wshtmlcart.innerHTML = wstextcart;\n  const wsnewBoxCart =wshtmlcart.querySelector("#shopify-section-cart-drawer .cart-container").innerHTML;\n  document.querySelector("#shopify-section-cart-drawer .cart-container").innerHTML = wsnewBoxCart;\n   $("body .header__icons #cart-icon-bubble")[0].click();\n  }`
  },
  {
    id: '71',
    storeName: 'the-wondery-shop.myshopify.com',
    themeName: 'Avalanche',
    date: '2024-11-14',
    author: 'Y',
    code: `function wiseraddedtocart() {    \n        setTimeout(function () {\n      $.getJSON('/cart.js', function(cart) {\n        var ws_item_count = cart.item_count\n        $(".cart-count-bubble").remove();\n        $("#cart-icon-bubble").append('<div class="cart-count-bubble"><span aria-hidden="true">'+ws_item_count+'</span><span class="visually-hidden">'+ws_item_count+' item</span></div>');\n        $("body .header__icons #cart-icon-bubble")[0].click();\n      });\n    }, 1000);\n\n\n      }\n\n\n/*wiser Code to show  widgets in cart drawer  */\n    var $wsInit = 0;\n    var $wsInterval = setInterval(function () {\n      var $wsCartCnt =  $(".header__icon--cart span[data-ajax-cart-bind-state]").text()[0];\n      $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\n      if ($("body .cart-drawer-overlay").hasClass("open") && $wsDrawerDivCnt == 8 && $wsInit == 0) {                \n       $wsInit = 1;\n        window.WISER_INIT("cart", 1);\n        setTimeout(function () {\n          $wsInit = 0;\n        }, 5000);\n      }\n    }, 100);`
  },
  {
    id: '72',
    storeName: 'the-perfect-hoop.myshopify.com',
    themeName: 'Spark',
    date: '2024-11-11',
    author: 'Y',
    code: `function wiseraddedtocart(){\n  const quickCartInstance = window.quickCartInstance(document.querySelector(".quick-cart"))\n quickCartInstance.open();\n}`
  },
  {
    id: '73',
    storeName: '9bd82c-2.myshopify.com',
    themeName: 'Stiletto',
    date: '2024-11-11',
    author: 'Y',
    code: `function wiseraddedtocart() {\n  if (window.quickCartInstance && typeof window.quickCartInstance.openQuickCart === 'function') {\n    window.quickCartInstance.refreshQuickCart();\n        setTimeout(() => {\n           window.quickCartInstance.openQuickCart();\n          }, 300);\n  }\n  }\n \n  // theme based code\n       \n        var $wsInit = 0;\n        var $wsInterval = setInterval(function () {\n          var $wsCartCnt = $(".evm_wiser_count").text()[0];\n          $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\n          if ($("body .quick-cart__wrapper").hasClass("active") &&            $wsDrawerDivCnt == 8 && $wsInit == 0) {                \n           $wsInit = 1;\n            window.WISER_INIT("cart", 1);\n            setTimeout(function () {\n              $wsInit = 0;\n            }, 5000);\n          }\n        }, 100);`
  },
  {
    id: '74',
    storeName: 'marithefrancoisgirbaud.myshopify.com',
    themeName: 'Symmetry',
    date: '2024-11-07',
    author: 'D',
    code: `function wiseraddedtocart(){\n    $(".cart-drawer").load(location.href + " .cart-drawer>*", "");\n$.getJSON('/cart.js', function(cart) {\n  var ws_item_count = cart.item_count\n  $(".cart-link__count").remove();\n  $(".cart-link__icon").append(\`<span class="cart-link__count">\${ws_item_count}</span> \`)\n  setTimeout(function() {\n    $("body .cart-link__icon").trigger('click');\n  }, 1000 );\n});\n}`
  },
  {
    id: '75',
    storeName: 'revision-skincare.myshopify.com',
    themeName: 'dawn',
    date: '2024-11-07',
    author: 'D',
    code: `// No specific code provided in source, just theme name. \n// Please verify if code is needed.`
  },
  {
    id: '76',
    storeName: 'vapingland-com.myshopify.com',
    themeName: 'ella',
    date: '2024-10-23',
    author: 'D',
    code: `function wiseraddedtocart(){\n    $.getJSON('/cart.js', function(cart) {\n      if (window.page_name === 'cart') {\n        wsHaloJs.updateCart(cart);\n      }else{\n        wsHaloJs.updateSidebarCart(cart);  \n      }\n       document.querySelector('a[href="/cart"]').click()\n    });\n  }`
  },
  {
    id: '77',
    storeName: 'd8dc91-1a.myshopify.com',
    themeName: 'Beauty',
    date: '2024-10-16',
    author: 'D',
    code: `function wiseraddedtocart(){\n    $(document).on("click", "#CartDrawer-Overlay", function(e) {\n      e.preventDefault();\n      $("#CartDrawer").parent().removeClass("active");\n    });  \n    $(".drawer").load(location.href + " .drawer>*", "");\n    setTimeout(function() {\n      $(".drawer").addClass("active");\n      $(".drawer").removeClass("is-empty");\n    },1000);\n   }`
  },
  {
    id: '78',
    storeName: 'rforrabbit1.myshopify.com',
    themeName: 'Ella',
    date: '2024-09-13',
    author: 'N',
    code: `function wiseraddedtocart(){\n    $.getJSON('/cart.js', function(cart) {\n      if (window.page_name === 'cart') {\n        wsHaloJs.updateCart(cart);\n      }else{\n        wsHaloJs.updateSidebarCart(cart);  \n      }\n      window.OPEN_CART();\n    });\n  }\n\n\n  /* theme based code */\n  var $wsInit = 0;\n  var $wsCartCntOld = 0;\n  var $wsInterval = setInterval(function () {\n    var $wsCartCnt = parseInt($(".cart-count-bubble .text").text());\n    if ($("body").hasClass("cart-sidebar-show") && $wsCartCnt != $wsCartCntOld && $wsInit == 0) {\n      $wsCartCntOld = $wsCartCnt;\n      $wsInit = 1;\n     window.WISER_INIT("cart", 1);\n      setTimeout(function () {\n        $wsInit = 0;\n      }, 3000);\n    }\n  }, 500);`
  },
  {
    id: '79',
    storeName: '6dc86d-ba.myshopify.com',
    themeName: 'Eurus',
    date: '2024-09-12',
    author: 'Y',
    code: `function wiseraddedtocart(){\n    Alpine.store('xMiniCart').reLoad();\n   Alpine.store('xMiniCart').openCart();\n }`
  },
  {
    id: '80',
    storeName: 'centrale-fillers.myshopify.com',
    themeName: 'Gradibase',
    date: '2024-09-02',
    author: 'N',
    code: `var wsChkFao = 0;\n    wsGetCartCntOld = 0;\n    let wsCartInterValFao = setInterval(function() {\n    let wsGetCartCnt = $(".button-cart-counter").text();\n      if (parseInt(wsGetCartCnt) != parseInt(wsGetCartCntOld) && wsChkFao == 0) {\n        window.WISER_INIT('cart',1);\n        wsChkFao = 1;\n        wsGetCartCntOld = wsGetCartCnt;\n        // clearInterval(wsCartInterValFao);\n        setTimeout(function () {\n          wsChkFao = 0;\n        }, 3000);\n      }\n    }, 100);`
  },
  {
    id: '81',
    storeName: 'fao-schwarz.myshopify.com',
    themeName: 'Impulse',
    date: '2024-09-03',
    author: 'N',
    code: `var wsChkFao = 0;\n  setTimeout(function () {\n    let wsCartInterValFao = setInterval(function() {\n      if ($(".cart-link__bubble").hasClass("cart-link__bubble--visible") && wsChkFao == 0) {\n        wsChkFao = 1;\n        clearInterval(wsCartInterValFao);\n        window.WISER_INIT('cart',1);\n      }\n    }, 500);\n  }, 4000);\n \n  function wiserOpenCartDrawer(pid){\n   fetch('/cart/add.js', {\n      method: 'POST',\n      headers: {\n          'Content-Type': 'application/json',\n          'Accept': 'application/json'\n      },\n      body: JSON.stringify({\n          id: pid,\n          quantity: 1\n      })\n    })\n    .then(response => response.json())\n    .then(data => {\n      window.WISER_INIT('cart',1);\n      $(".evm-wi-quick-close-btn").trigger('click');\n      const wsCartObjQickView = new theme.CartDrawer();\n      wsCartObjQickView.open();\n    })\n    .catch((error) => {\n      console.error('Error:', error);\n    });\n  }\n   // theme based code\n  function wiseraddedtocart(){\n    const wsCartDrawerObj = new themen.CartDrawer();\n    wsCartDrawerObj.open();\n    window.WISER_INIT('cart',1);\n  }`
  },
  {
    id: '82',
    storeName: '1921movement.myshopify.com',
    themeName: 'Dawn',
    date: '2024-09-02',
    author: 'D',
    code: `<script>\n function wiseraddedtocart(){\n    const wsevent = new CustomEvent('wiser:addedToCart');\n    window.dispatchEvent(wsevent);\n  }\n </script>`
  },
  {
    id: '83',
    storeName: 'royale-lighting.myshopify.com',
    themeName: 'Warehouse',
    date: '2024-08-30',
    author: 'D',
    code: `<script>\n function wiseraddedtocart(){\ndocument.documentElement.dispatchEvent(new CustomEvent('product:added', {\n      bubbles: true,\n        detail: {\n         quantity: 1\n       }\n     }));\n }\n </script>`
  },
  {
    id: '84',
    storeName: 'camessi-collection.myshopify.com',
    themeName: 'Taiga',
    date: '2024-08-01',
    author: 'D',
    code: `<script>\nfunction wiseraddedtocart(){\ndocument.dispatchEvent(new CustomEvent('ajaxProduct:added', {\n}));\n  }\n </script>`
  },
  {
    id: '85',
    storeName: 'jean-rachel-jewelry.myshopify.com',
    themeName: 'Pipeline',
    date: '2024-06-25',
    author: 'D',
    code: `var $wsInit = 0;\n    var oldCount = 0;\n      var $wsInterval = setInterval(function() {\n        const spanElement = document.getElementById('evm_cart_count');\n          var newCount = spanElement.dataset.headerCartCount      \n        $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\n        if ($wsDrawerDivCnt == 8 && $wsInit == 0 && oldCount !=  newCount) {  \nconsole.log("In")  \n          $wsInit = 1;\n          window.WISER_INIT('cart',1);\n          setTimeout(function () {\n            $wsInit = 0;\n          }, 3000);\n        }\n      }, 1000);`
  },
  {
    id: '86',
    storeName: 'indiatrend1.myshopify.com',
    themeName: 'Forge',
    date: '2024-06-21',
    author: 'Y',
    code: `function wiseraddedtocart() {          \n    let config = document.getElementById('cart-config');\n        if ( !config ) return false;\n        config = JSON.parse(config.innerHTML || '{}');\n         console.log(config)  \n   \n   \n    window.WAU.ThemeCart.getCart()\n      .then(cartData => {        \n         return cartData;\n     })\n      .then(finalValue => {\n        window.WAU.AjaxCart.updateView(config, finalValue);  \n          if (!$(".slideout__drawer-right.mini-cart").hasClass("slideout--active")){\n            $(".slideout__trigger--open span").trigger( "click" )\n         }    \n      })\n      .catch(error => {\n        // Handle any errors that occur during the promise chain\n        console.error('Error:', error);\n      });\n    }\n    <script>\n    var $wsInit = 0;\n    var oldCount = 0;\n      var $wsInterval = setInterval(function() {\n          var newCount = document.querySelector(".js-mini-cart-trigger .js-cart-count").innerText      \n        $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\n        if ($(".slideout__drawer-right.mini-cart").hasClass("slideout--active") && $wsDrawerDivCnt == 8 && $wsInit == 0 && oldCount !=  newCount) {      \n          $wsInit = 1;\n          window.WISER_INIT('cart',1);\n          setTimeout(function () {\n            $wsInit = 0;\n          }, 3000);\n        }\n      }, 1000);\n      </script>`
  },
  {
    id: '87',
    storeName: 'stratum-aesthetics.myshopify.com',
    themeName: 'Pipeline',
    date: '2024-06-21',
    author: 'D',
    code: `function wiseraddedtocart() {          \ndocument.documentElement.dispatchEvent(new CustomEvent('theme:cart:init', { bubbles: true }));\ndocument.dispatchEvent(new CustomEvent('theme:cart:reload', { bubbles: true }));  \n}`
  },
  {
    id: '88',
    storeName: 'imperio-brazilian.myshopify.com',
    themeName: 'Dawn',
    date: '2024-06-17',
    author: 'Y',
    code: `wiseraddtocart()`
  },
  {
    id: '89',
    storeName: 'skillmaticsindia.myshopify.com',
    themeName: 'Wokiee',
    date: '2024-06-14',
    author: 'Y',
    code: `$( document ).ready(function() {\n  var $wsInit = 0;\n  var $wsCartCntOld = 0;\n  var $wsInterval = setInterval(function() {\n  var $wsCartCnt    = parseInt($(".tt-badge-cart").text())\nvar parentElement = $(".hs-sticky-cart");\n      var emptyElement = $(".hs-empty-cart");\n      var newElement = $(\`<div class="evm-drawer-main" data-scrollable>\n                        <div class="evm-drawer-related-product"></div>\n                        <div class="evm-drawer-related-viewed-browsing"></div>\n                        <div class="evm-drawer-recommended-products"></div>\n                        <div class="evm-drawer-recently-viewed"></div>\n                        <div class="evm-drawer-arrivals-product"></div>\n                        <div class="evm-drawer-featured-product"></div>\n                        <div class="evm-drawer-popular-products"></div>\n                        <div class="evm-drawer-trending-products"></div>\n                        </div>\`);\n    if ($(".hs-popup-cart-sp-load").hasClass("hs-active") && $wsCartCnt != $wsCartCntOld && $wsInit == 0) {\nvar $wsDrawerDivCnt  = $("body div.evm-drawer-main  div").length;      \n        if($wsCartCnt > 0 &&  $wsDrawerDivCnt < 8){\n            parentElement.after(newElement);\n        }\n           \n      $wsCartCntOld = $wsCartCnt;\n      $wsInit = 1;\n      window.WISER_INIT('cart',1);\n      setTimeout(function () {\n        $wsInit = 0;\n      }, 3000);\n    }\n        if ($(".hs-popup-cart-sp-load").hasClass("hs-active") && $(".hs-empty-cart") && $wsInit == 0) {  \n          var $wsDrawerDivCnt  = $("body div.evm-drawer-main  div").length;\n          if($wsCartCnt == 0 && $wsDrawerDivCnt < 8 ){        \n          emptyElement.after(newElement);\n          }\n       $wsInit = 1;\n          if($wsDrawerDivCnt == 8 ){\n            window.WISER_INIT('cart',1);\n            $(".hs-body-layout").css({"overflow-y": "auto"})\n          }        \n        setTimeout(function () {\n          $wsInit = 0;\n        }, 3000);\n       }\n  }, 500);\n});`
  },
  {
    id: '90',
    storeName: 'rmid.myshopify.com',
    themeName: 'Palo Alto',
    date: '2024-06-14',
    author: 'Y',
    code: `function wiseraddedtocart() {\n  window.cart.getCart()\n  window.cart.openCartDrawer()\n}\n\n\n/* tehem based code */\n\n\n$( document ).ready(function() {\n  var ws_flag = 0;\n  var cart_count_old = 0 ;\n// var cartHasItem = window.cart.hasItemsInCart();  \nsetInterval(function () {\n  var cart_count = window.cart.items.length\n  var drawer = document.getElementById('evm-drawer-main');\n\n\n  if (drawer != null){\n     if (cart_count == 0) {\n    drawer.style.display = 'none';\n  } else {\n    drawer.style.display = 'block';\n  }\n  }\n    if (cart_count_old != cart_count && cart_count > 0   && ws_flag == 0) {      \n      ws_flag = 1;\n      cart_count_old = cart_count;\n      window.WISER_INIT('cart',1);\n      setTimeout(function() {          \n        ws_flag= 0;\n      }, 3000);\n    }\n  }, 100);\n})`
  },
  {
    id: '91',
    storeName: 'hardman-design-eu.myshopify.com',
    themeName: 'Split',
    date: '2024-06-16',
    author: 'Y',
    code: `function wiseraddedtocart(){\n  window.refreshCart();\n}\nwiseraddedtocart();\n\n/* theme based code */\n\n\nvar $wsInit = 0;\nvar old_cartCount= 0;\n  var $wsInterval = setInterval(function() {\nvar cartCount  = document.querySelector('[data-header-cart-count]').innerText;\n   \n      $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;\nconsole.log("$wsDrawerDivCnt" , $wsDrawerDivCnt)\n    if ($("body #site-cart").hasClass("active") && old_cartCount !== cartCount && $wsInit == 0) {\n      $wsInit = 1;\n      old_cartCount = cartCount\n      window.WISER_INIT('cart',1);\n      setTimeout(function () {\n        $wsInit = 0;\n      }, 3000);\n    }\n  }, 1000);`
  },
  {
    id: '92',
    storeName: '237a95-2.myshopify.com',
    themeName: 'Impulse',
    date: '2024-05-23',
    author: 'D',
    code: `<script>\n      function wiseraddedtocart(){\n     \t\tconst wsCartDrawerObj = new themen.CartDrawer();\n        wsCartDrawerObj.open();\n        }\n    </script>`
  },
  {
    id: '93',
    storeName: 'minimalist-global.myshopify.com',
    themeName: 'Motion',
    date: '2024-05-22',
    author: 'Y',
    code: `function wiseraddedtocart(){\n  var cartNew  = new theme.CartDrawer();\n  document.body.classList.add('cart-has-items');\n  cartNew.cartForm.updateCount();\n  cartNew.drawer.open();\n }\n\n\n\n\n\n\n//  theme based code\n    var old_cart_count = 0;\n  setInterval(function () {\n    var cart_count = $(".cart-link__bubble").attr("data-items");\n    if ($("#CartDrawer").hasClass("drawer--is-open") && cart_count != old_cart_count) {\n      old_cart_count = cart_count;\n      window.WISER_INIT('cart',1);\n    }\n  }, 100);`
  },
  {
    id: '94',
    storeName: 'b11b0d-2.myshopify.com',
    themeName: 'Motion',
    date: '2024-05-08',
    author: 'D',
    code: `function wiseraddedtocart(){\n  var cartNew  = new theme.CartDrawer();\n  document.body.classList.add('cart-has-items');\n  cartNew.cartForm.updateCount();\n  cartNew.drawer.open();\n }`
  },
  {
    id: '95',
    storeName: 'birch-robot.myshopify.com',
    themeName: 'Streamline',
    date: '2024-05-03',
    author: 'Y',
    code: `function wiseraddedtocart(){\n  var cartNew  = new theme.CartDrawer();\n  document.body.classList.add('cart-has-items');\n  cartNew.cartForm.updateCount();\n  cartNew.drawer.open();\n }`
  },
  {
    id: '96',
    storeName: 'hypeach-boutique.myshopify.com',
    themeName: 'Upscale',
    date: '2024-04-30',
    author: 'N',
    code: `function wiseraddedtocart(){\n        $("#CartDrawer").load(location.href + " #CartDrawer>*", "");\n        setTimeout(function() {\n          const wsChkAriaExpd = $('#HeaderCartIcon button').attr("aria-expanded");\n          if(wsChkAriaExpd == "false") {\n            $("#HeaderCartIcon button").trigger('click');\n          }\n        }, 1000);\n        setTimeout(function () {\n          $.getJSON('/cart.js', function(cart) {\n            var ws_item_count = cart.item_count\n            $(".header-cart-icon__count").remove();\n            $("#HeaderCartIcon").append('<div class="header-cart-icon__count  small-text"><span class="evm_wiser_count" aria-hidden="true">'+ws_item_count+'</span><span class="sr-only">'+ws_item_count+' item</span></div>');        \n          });\n         }, 1000);          \n      }\n\n      /* LOAD WIDGETS ON-LOAD CART DRAWER */\n      var $wsInit = 0;\n      var $wsInterval = setInterval(function() {\n        var $wsDrawerDivCnt = $("body div.evm-drawer-main div").length;        \n        var wsChkAttr = $('#CartDrawer').attr('open');        \n        if (typeof wsChkAttr !== 'undefined' && wsChkAttr !== false && $wsDrawerDivCnt == 8 && $wsInit == 0) {          \n          $wsInit = 1;          \n          window.WISER_INIT('cart',1);          \n          setTimeout(function () {\n            $wsInit = 0;\n          }, 3000);          \n        }\n      }, 2000);`
  },
  {
    id: '97',
    storeName: 'wholesale-matrboomie-com.myshopify.com',
    themeName: 'Custom',
    date: '2024-04-22',
    author: 'D',
    code: `<!--Wiser cartdrwaer shipping bar-->\n{% if customer %}\n  {% assign tag_to_check = 'RPP' %}\n  {% assign customer_tags = customer.tags | split: ', ' %}\n  {% for tag in customer_tags %}\n    {% if tag contains tag_to_check %}\n       <style>\n         div#wsFsbMain, div#wsProgWr {\n              display: none;\n          }\n       </style>    \n      {% endif %}\n  {% endfor %}\n{% endif %}\n<!--Wiser cartdrwaer shipping bar end-->`
  },
  {
    id: '98',
    storeName: 'raithclothing.myshopify.com',
    themeName: 'impulse',
    date: '2024-04-11',
    author: 'N',
    code: `wiseraddedtocart();\n   function wiseraddedtocart(){\n     new theme.CartDrawer();\n     $(".js-drawer-open-cart span").trigger("click");\n   }`
  }
];