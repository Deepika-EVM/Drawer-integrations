import * as firebaseApp from 'firebase/app';
import { getFirestore, collection, getDocs, addDoc, query, orderBy } from 'firebase/firestore';
import { Snippet } from '../types';

// Fix: Use namespace import and cast to any to bypass potential type definition issues with firebase/app
const initializeApp = (firebaseApp as any).initializeApp;

// TODO: User must replace these with their actual Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyD-PLACEHOLDER-KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};

// Check if config is placeholder
const isConfigured = !firebaseConfig.apiKey.includes("PLACEHOLDER");

let db: any;

if (isConfigured) {
  try {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app);
  } catch (error) {
    console.error("Firebase initialization error:", error);
  }
}

export const fetchSnippets = async (): Promise<Snippet[]> => {
  if (!isConfigured || !db) return [];
  
  try {
    const q = query(collection(db, "snippets"), orderBy("date", "desc"));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map((doc: any) => ({
      id: doc.id,
      ...doc.data()
    } as Snippet));
  } catch (error) {
    console.error("Error fetching snippets:", error);
    return [];
  }
};

export const addSnippetToFirebase = async (snippet: Omit<Snippet, 'id'>): Promise<string | null> => {
  if (!isConfigured || !db) {
    console.warn("Firebase not configured. Data will only be saved locally for this session.");
    return null;
  }
  
  try {
    const docRef = await addDoc(collection(db, "snippets"), snippet);
    return docRef.id;
  } catch (error) {
    console.error("Error adding snippet:", error);
    throw error;
  }
};