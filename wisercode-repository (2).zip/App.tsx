import React, { useState, useEffect, useMemo } from 'react';
import { Search, Plus, Code, Layers, User, Layout, Database, ChevronLeft, ChevronRight } from 'lucide-react';
import CodeBlock from './components/CodeBlock';
import AddModal from './components/AddModal';
import { Snippet, SortOption } from './types';
import { INITIAL_DATA } from './services/initialData';
import { addSnippetToFirebase, fetchSnippets } from './services/firebase';

const ITEMS_PER_PAGE = 50;

const App: React.FC = () => {
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('date-desc');
  const [firebaseActive, setFirebaseActive] = useState(true);
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);

  // Initialize Data
  useEffect(() => {
    const init = async () => {
      // 1. Load Local Data first (Instant load)
      setSnippets(INITIAL_DATA);

      try {
        // 2. Fetch Firebase Data
        const remoteData = await fetchSnippets();
        if (remoteData.length > 0) {
          setSnippets(prev => {
             const existingIds = new Set(prev.map(p => p.id));
             // Only add remote items that don't collide with local IDs (though IDs should be unique)
             const newItems = remoteData.filter(d => !existingIds.has(d.id));
             return [...newItems, ...prev]; 
          });
        }
      } catch (e) {
        console.warn("Firebase fetch failed or not configured, using local data only.");
        setFirebaseActive(false);
      }
    };
    init();
  }, []);

  const handleSaveSnippet = async (newSnippetData: Omit<Snippet, 'id'>) => {
    let newId = Date.now().toString(); 
    try {
      // 1. Save to Database
      const fbId = await addSnippetToFirebase(newSnippetData);
      if (fbId) newId = fbId;
    } catch (e) {
      console.warn("Could not save to firebase, saving locally");
    }

    const newSnippet: Snippet = {
      id: newId,
      ...newSnippetData
    };
    
    // 2. Update UI Immediately (Prepend to list)
    setSnippets(prev => [newSnippet, ...prev]);
    
    // Reset to first page to show the new item
    setCurrentPage(1);
    setSortBy('date-desc');
  };

  // Filter & Sort Logic
  const filteredSnippets = useMemo(() => {
    const lowerQuery = searchQuery.toLowerCase().trim();
    
    const filtered = snippets.filter(s => {
      return (
        s.themeName.toLowerCase().includes(lowerQuery) || 
        s.storeName.toLowerCase().includes(lowerQuery) ||
        s.author.toLowerCase().includes(lowerQuery) || 
        s.code.toLowerCase().includes(lowerQuery)
      );
    });

    return filtered.sort((a, b) => {
      if (sortBy === 'date-desc') return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (sortBy === 'date-asc') return new Date(a.date).getTime() - new Date(b.date).getTime();
      if (sortBy === 'theme-asc') return a.themeName.localeCompare(b.themeName);
      return 0;
    });
  }, [snippets, searchQuery, sortBy]);

  // Pagination Logic
  const totalPages = Math.ceil(filteredSnippets.length / ITEMS_PER_PAGE);
  const paginatedSnippets = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredSnippets.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredSnippets, currentPage]);

  // Reset page when search or sort changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, sortBy]);

  // Derived Stats
  const totalThemes = snippets.length;
  const uniqueStores = new Set(snippets.map(s => s.storeName)).size;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans selection:bg-indigo-100 selection:text-indigo-800 flex flex-col">
      
      {/* Navbar */}
      <nav className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="bg-indigo-600 p-2 rounded-lg shadow-sm">
                <Code className="text-white h-5 w-5" />
              </div>
              <div className="flex flex-col">
                <h1 className="text-xl font-bold text-slate-900 leading-none tracking-tight">WiserCode</h1>
                <p className="text-[10px] text-slate-500 font-semibold tracking-wide uppercase mt-0.5">Integration Library</p>
              </div>
            </div>
            
            <button 
              onClick={() => setIsModalOpen(true)}
              className="hidden md:flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all shadow-md shadow-indigo-200 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:shadow-sm"
            >
              <Plus size={18} strokeWidth={2.5} />
              Add Integration
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full">
        
        {/* Header Stats & Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900 mb-3 tracking-tight">Theme Repository</h2>
            <p className="text-slate-500 text-lg max-w-2xl leading-relaxed">
              Centralized hub for Shopify drawer integration codes. Search by theme, store, or author.
            </p>
          </div>
          
          <div className="flex gap-4">
             <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col items-center min-w-[120px]">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Total Codes</span>
                <span className="text-3xl font-bold text-indigo-600">{totalThemes}</span>
             </div>
             <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col items-center min-w-[120px]">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Stores</span>
                <span className="text-3xl font-bold text-slate-700">{uniqueStores}</span>
             </div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-2 mb-10">
          <div className="flex flex-col md:flex-row gap-2">
            
            {/* Search Input */}
            <div className="relative flex-grow group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
              </div>
              <input
                type="text"
                className="block w-full pl-11 pr-4 py-3.5 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-slate-50 focus:ring-0 text-base transition-all"
                placeholder="Search by theme, store URL, or author name (e.g. 'D')..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            {/* Filters */}
            <div className="flex items-center gap-2 border-t md:border-t-0 md:border-l border-slate-100 pt-2 md:pt-0 md:pl-2">
              <div className="relative">
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="appearance-none bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium rounded-xl px-4 py-3.5 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 cursor-pointer transition-colors border border-transparent"
                >
                  <option value="date-desc">Newest First</option>
                  <option value="date-asc">Oldest First</option>
                  <option value="theme-asc">Theme (A-Z)</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-500">
                  <Layout size={16} />
                </div>
              </div>
              
              <button 
                   onClick={() => setIsModalOpen(true)}
                   className="md:hidden flex items-center justify-center bg-indigo-600 text-white p-3.5 rounded-xl shadow-md active:scale-95 transition-transform"
                >
                  <Plus size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 mb-12">
          {paginatedSnippets.length > 0 ? (
            paginatedSnippets.map(snippet => (
              <CodeBlock key={snippet.id} snippet={snippet} />
            ))
          ) : (
            <div className="col-span-full py-24 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white shadow-sm border border-slate-100 mb-6">
                <Database className="h-8 w-8 text-slate-300" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">No results found</h3>
              <p className="text-slate-500 mt-2 mb-8 max-w-md mx-auto">
                We couldn't find any integration codes matching "{searchQuery}".
                Try searching for a different theme name or author.
              </p>
              <button 
                onClick={() => { setSearchQuery(''); setIsModalOpen(true); }}
                className="inline-flex items-center gap-2 text-indigo-600 hover:text-indigo-800 font-semibold hover:bg-indigo-50 px-4 py-2 rounded-lg transition-colors"
              >
                <Plus size={18} />
                Add new integration
              </button>
            </div>
          )}
        </div>

        {/* Pagination Controls */}
        {filteredSnippets.length > ITEMS_PER_PAGE && (
          <div className="flex justify-center items-center gap-4 border-t border-slate-200 pt-8">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft size={16} />
              Previous
            </button>
            
            <div className="text-sm font-medium text-slate-600">
              Page <span className="text-indigo-600 font-bold">{currentPage}</span> of {totalPages}
            </div>
            
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
              <ChevronRight size={16} />
            </button>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 py-8 bg-white mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center text-sm text-slate-500">
          <p>© {new Date().getFullYear()} WiserCode. Internal Development Tool.</p>
          <div className="flex items-center gap-2 mt-2 md:mt-0">
             <div className={`h-2 w-2 rounded-full ${firebaseActive ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
             <span>{firebaseActive ? 'Database Connected' : 'Local Mode'}</span>
          </div>
        </div>
      </footer>

      {/* Modal */}
      <AddModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveSnippet}
      />
    </div>
  );
};

export default App;