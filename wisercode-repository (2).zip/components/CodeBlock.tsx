import React, { useState } from 'react';
import { Copy, Check, ExternalLink, Calendar, User, ShoppingBag, Code2 } from 'lucide-react';
import { Snippet } from '../types';

interface CodeBlockProps {
  snippet: Snippet;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ snippet }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(snippet.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Helper to make URL look cleaner
  const cleanStoreUrl = snippet.storeName
    .replace(/^https?:\/\//, '')
    .replace(/\/$/, '')
    .replace(/^www\./, '');

  return (
    <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-[0_2px_8px_-3px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_20px_-6px_rgba(0,0,0,0.1)] transition-all duration-300 flex flex-col h-full group hover:border-indigo-100">
      
      {/* Card Header */}
      <div className="p-5 flex flex-col gap-3 relative">
        <div className="flex justify-between items-start">
          <div className="min-w-0 pr-4">
             <div className="flex items-center gap-2 mb-1">
               <span className="p-1 rounded bg-indigo-50 text-indigo-600">
                 <ShoppingBag size={14} strokeWidth={2.5} />
               </span>
               <h3 className="text-lg font-bold text-slate-800 truncate" title={snippet.themeName}>
                 {snippet.themeName}
               </h3>
             </div>
             <a 
              href={`https://${cleanStoreUrl}`} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-xs font-medium text-slate-400 hover:text-indigo-600 transition-colors flex items-center gap-1.5 truncate"
            >
              <ExternalLink size={10} />
              {cleanStoreUrl}
            </a>
          </div>
          
          <div className="flex flex-col items-end gap-1 shrink-0">
             <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-semibold border border-slate-200" title="Author">
               <User size={12} className="text-slate-400" />
               {snippet.author}
             </div>
             <div className="text-[10px] font-medium text-slate-400 flex items-center gap-1 mt-1">
                <Calendar size={10} />
                {snippet.date}
             </div>
          </div>
        </div>
      </div>

      {/* Code Preview Area */}
      <div className="relative flex-grow bg-[#1e293b] flex flex-col">
        {/* Toolbar inside code block */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-slate-700/50 bg-[#0f172a]">
           <div className="flex items-center gap-2">
              <Code2 size={12} className="text-slate-500" />
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">JavaScript</span>
           </div>
           
           <button
            onClick={handleCopy}
            className={`
              flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide transition-all
              ${copied 
                ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20' 
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }
            `}
          >
            {copied ? <Check size={12} /> : <Copy size={12} />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>

        {/* Code Content */}
        <div className="relative overflow-hidden flex-grow group-hover:bg-[#1e293b] transition-colors">
           <div className="absolute top-0 left-0 w-full h-full overflow-auto custom-scrollbar p-4">
             <pre className="text-xs font-mono leading-relaxed text-slate-300 whitespace-pre-wrap break-all">
               <code>{snippet.code}</code>
             </pre>
           </div>
           {/* Fade at bottom */}
           <div className="absolute bottom-0 left-0 w-full h-8 bg-gradient-to-t from-[#1e293b] to-transparent pointer-events-none"></div>
        </div>
        
        {/* Fixed height for visual consistency */}
        <div className="h-48"></div> 
      </div>
    </div>
  );
};

export default CodeBlock;